// Show the first tab and hide the rest


$(document).ready(function(){


//     $(".hamnav").click(function(){
//         $("nav").fadeToggle("disp");
//       })
//     })
//     $(document).ready(function(){
//       $(".hamnav").click(function(){
//         $(".bar1").toggleClass("change");
//       })
//     })

//     function myFunction(x) {
//       x.classList.toggle("change");
// // hamberger menu start
//    $(".hamnav").click(function(){
//     $(."nav").toggleClass("logo-block nav");

 $('#tabs-nav li:first-child').addClass('active');
 $('.tab-content').hide();
 $('.tab-content:first').show();

// Click function
$('#tabs-nav li').click(function(){
  $('#tabs-nav li').removeClass('active');
  $(this).addClass('active');
  $('.tab-content').hide();
  
  var activeTab = $(this).find('a').attr('href');
  $(activeTab).fadeIn();
  return false;
});;
function openFirstPanel(){
  $('.accordion > dt:first-child').next().addClass('active').slideUp();
}

(function($) {
  var allPanels = $('.accordion > dd').hide();
  
  openFirstPanel();
    
  $('.accordion > dt > a').click(function() {
      $this = $(this);
      $target =  $this.parent().next();
      
      if($target.hasClass('active')){
        $target.removeClass('active').slideUp(); 
      }
      else {
        allPanels.removeClass('active').slideUp();
        $target.addClass('active').slideDown();
      }
      
    return false;
  });

})(jQuery);

});

  
    
    